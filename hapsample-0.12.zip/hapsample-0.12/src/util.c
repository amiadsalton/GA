/* ***************************************************************************

RENCI Open Source Software License
The University of North Carolina at Chapel Hill

The University of North Carolina at Chapel Hill (the "Licensor") through
its Renaissance Computing Institute (RENCI) is making an original work of
authorship (the "Software") available through RENCI upon the terms set
forth in this Open Source Software License (this "License").  This License
applies to any Software that has placed the following notice immediately
following the copyright notice for the Software:  Licensed under the RENCI
Open Source Software License v. 1.0.

Licensor grants You, free of charge, a world-wide, royalty-free,
non-exclusive, perpetual, sublicenseable license to do the following to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimers.

. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimers in the
documentation and/or other materials provided with the distribution.

. Neither You nor any sublicensor of the Software may use the names of
Licensor (or any derivative thereof), of RENCI, or of contributors to the
Software without explicit prior written permission.  Nothing in this
License shall be deemed to grant any rights to trademarks, copyrights,
patents, trade secrets or any other intellectual property of Licensor
except as expressly stated herein.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE CONTIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

You may use the Software in all ways not otherwise restricted or
conditioned by this License or by law, and Licensor promises not to
interfere with or be responsible for such uses by You.  This Software may
be subject to U.S. law dealing with export controls.  If you are in the
U.S., please do not mirror this Software unless you fully understand the
U.S. export regulations.  Licensees in other countries may face similar
restrictions.  In all cases, it is licensee's responsibility to comply
with any export regulations applicable in licensee's jurisdiction.

*************************************************************************** */
#include <math.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#include <timeapi.h>
#else
#include <sys/time.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include "util.h"

static int seeded = 0;
static unsigned int seed_number ;

int **
build_combo_table (int exp, int *rows, int *cols)
{
	int **r, i, j;

	*cols = exp;
	*rows = (int) pow (3.0, (double) exp);
	r = (int **) malloc (*rows * (sizeof (int *)));
	for (i = 0; i < *rows; i++)
		r[i] = malloc (*cols * sizeof (int));
	for (i = 0; i < *rows; i++) {
		int remaining = i;
		for (j = 0; j < *cols; j++) {
			int curd = remaining % 3;
			remaining = floor ((double) remaining / 3.0);
			r[i][j] = curd;
		}
	}
	return r;
}

/*
num_loaded should contain recommended block size on input
*/
char **
load_strings (const char *f, int max_line_len, int *num_loaded)
{
	FILE *fp;
	char *line = NULL;
	char **fnames = NULL;
	int cur_line_space = 0;
	int blocksize = 16;

	if (*num_loaded > 0) {
		cur_line_space = (*num_loaded);
		blocksize = (*num_loaded);
	}
	if ((fnames =
	     (char **) malloc (cur_line_space * sizeof (char *))) == NULL) {
		printf ("out of mem\n");
		return NULL;
	}
	*num_loaded = 0;

	/* first load the snp names to include */
	if ((fp = fopen (f, "r")) == NULL) {
		perror (f);
		return NULL;
	}

	line = (char *) malloc (max_line_len);
	while ((fgets (line, max_line_len, fp))) {
		int len;
		/*trim(line); */
		if ((!line) || (!*line) || (*line == '\r') || (*line == '\n')) {
			continue;
		}
		if (((*num_loaded) + 1) == cur_line_space) {
			cur_line_space += blocksize;
			if ((fnames = (char **) realloc (fnames,
							 cur_line_space *
							 sizeof (char *))) ==
			    NULL) {
				printf ("out of mem\n");
				return NULL;
			}
		}
		len = strlen (line);

		if ((line[len - 1] == '\r') || (line[len - 1] == '\n'))
			line[len - 1] = '\0';
		if ((line[len - 2] == '\r') || (line[len - 2] == '\n'))
			line[len - 2] = '\0';
		if ((fnames[*num_loaded] = strdup (line)) == NULL) {
			free (fnames);
			return NULL;
		}
		*num_loaded += 1;
	}
	fclose (fp);
	free (line);
	return fnames;
}

void 	set_seed(unsigned int seed){
	
	seed_number = seed ;
	srand (seed_number);
	seeded = 1;

}

unsigned int	get_seed(){
	
	if (seeded == 0) {
// 		struct timeval tv;
// 		gettimeofday (&tv, NULL);
// 		seed_number  = tv.tv_usec ;
		srand (timeGetTime());
		seeded = 1;
	}
	return seed_number ;
}

double
rand_0_1 ()
{
	
	double r, x;
	if (seeded == 0) {
#ifdef _WIN32
        srand (timeGetTime());
#else
        struct timeval tv;
		gettimeofday (&tv, NULL);
		srand (tv.tv_usec);
#endif
		seeded = 1;
	}
	x = rand ();
	r = (x / (RAND_MAX+1));
	return r;
}

/*
N is desired number of values.
Clark Jeffries, RENCI
*/
int *
gen_poisson_nums (double mean, int N)
{
	double S[701], x[701];
	int i, *results;
	if ((mean < 0.0) || (N <= 0))
		return NULL;

	x[0] = exp ((double) (-1.0 * mean));
	for (i = 1; i < 701; i++)
		x[i] = mean * x[i - 1] / (double) i;
	S[0] = x[0];
	for (i = 1; i < 701; i++)
		S[i] = x[i] + S[i - 1];
	results = (int *) malloc (N * sizeof (int));
	for (i = 0; i < N; i++) {
		double R = rand_0_1 ();
		int j;
		for (j = 0; R >= S[j]; j++);
		results[i] = j;
	}
	return results;
}

int
cmpdoublep (const void *a, const void *b)
{
	if (*((double *) a) < *((double *) b))
		return -1;
	if (*((double *) a) > *((double *) b))
		return 1;
	return 0;
}

void
free_strings (char **f, int c)
{
	int i;
	for (i = 0; i < c; i++) {
		if (f[i]) {
			free (f[i]);
		}
	}
	free (f);
}

#ifdef _WIN32
int CreateDir(char* dir_name)
{
    HANDLE          hFind;
    WIN32_FIND_DATA FindFileData;

    // check if the directory already exists
    hFind = FindFirstFile(dir_name, &FindFileData);

    if (hFind == INVALID_HANDLE_VALUE) {
        return (CreateDirectory(dir_name, NULL) == TRUE);
    } 
    FindClose(hFind);

    return 1;
}
#else
#endif
