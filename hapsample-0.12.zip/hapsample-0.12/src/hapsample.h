/* ***************************************************************************

RENCI Open Source Software License
The University of North Carolina at Chapel Hill

The University of North Carolina at Chapel Hill (the "Licensor") through
its Renaissance Computing Institute (RENCI) is making an original work of
authorship (the "Software") available through RENCI upon the terms set
forth in this Open Source Software License (this "License").  This License
applies to any Software that has placed the following notice immediately
following the copyright notice for the Software:  Licensed under the RENCI
Open Source Software License v. 1.0.

Licensor grants You, free of charge, a world-wide, royalty-free,
non-exclusive, perpetual, sublicenseable license to do the following to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimers.

. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimers in the
documentation and/or other materials provided with the distribution.

. Neither You nor any sublicensor of the Software may use the names of
Licensor (or any derivative thereof), of RENCI, or of contributors to the
Software without explicit prior written permission.  Nothing in this
License shall be deemed to grant any rights to trademarks, copyrights,
patents, trade secrets or any other intellectual property of Licensor
except as expressly stated herein.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE CONTIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

You may use the Software in all ways not otherwise restricted or
conditioned by this License or by law, and Licensor promises not to
interfere with or be responsible for such uses by You.  This Software may
be subject to U.S. law dealing with export controls.  If you are in the
U.S., please do not mirror this Software unless you fully understand the
U.S. export regulations.  Licensees in other countries may face similar
restrictions.  In all cases, it is licensee's responsibility to comply
with any export regulations applicable in licensee's jurisdiction.

*************************************************************************** */
#ifndef _HAPSAMPLE_H_
#define _HAPSAMPLE_H_

#include "markers.h"
#define MAX_SNP_NAME_LEN 16

typedef struct _chromosome_metadata {
	int record_start, record_cnt;
	double max_ldu, min_ldu;
} chromosome_metadata_t;

typedef struct _summary {
	int record_cnt, sample_cnt, version_high, version_low,
		unknown_snp_cnt;
	chromosome_metadata_t chromosome[22];
} summary_t;

typedef struct _marker_record {
	char name[MAX_SNP_NAME_LEN];
	unsigned char chromosome;
	int location;
	double minor_allele_frequency,
		linkage_disequalibrium, genetic_location;
} marker_record_t;
#define RECORD_SIZE 45

typedef enum { CASE_CONTROL, TRIOS } simulation_type_t;

typedef struct _id_index_entry {
	char name[MAX_SNP_NAME_LEN];
	int record_num;
} id_index_entry_t;

typedef struct _user_prefs {
	simulation_type_t simulation_type;
	char snp_list_file[FILENAME_MAX], disease_model_file[FILENAME_MAX];
	int snp_cnt;
	char **snp_list;
} user_prefs_t;

typedef struct _disease_model {
	int snp_name_cnt;
	char **snp_names;
	int prob_cnt;
	double *prob;
	double *aprob;		/* accumulation of prob values in prob */
	marker_record_t *records;
	int combinations_rows, combinations_cols, **combinations,
		*probability_indices;
	int chr_to_record_index[22];	/* -1 if none, otherwise rec# */
	unsigned char **sample_data;
} disease_model_t;

/* Modified by Seunggeun Lee */
typedef struct _hapsample_instance {
	summary_t summary;
	id_index_entry_t *id_index;
	user_prefs_t user_prefs;
	char summary_file[FILENAME_MAX],
		records_file[FILENAME_MAX],
		rutgers_markers_dir[FILENAME_MAX],
		genotypes_file[FILENAME_MAX],
		database_dir[FILENAME_MAX],
		id_index_file[FILENAME_MAX], database_name[FILENAME_MAX],
		case_haplotypes_filename[FILENAME_MAX],
		case_genotypes_filename[FILENAME_MAX],
		anticase_haplotypes_filename[FILENAME_MAX],
		anticase_genotypes_filename[FILENAME_MAX],
		trio_haplotypes_filename[FILENAME_MAX],
		trio_genotypes_filename[FILENAME_MAX],
        output_directory[FILENAME_MAX];
	FILE *records_fp, *genotypes_fp;
	disease_model_t case_disease_model, anticase_disease_model;
	int simulation_snps_index[22];	/* records for all SNPs to be simulated */
	int simulation_snps_cnt[22];	/* number of snps for each chromosome */
	double recombination_factor;
	int simulation_snp_cnt;
	markers_t **rutgers_markers;
	int cases_cnt, anticases_cnt, max_snps, max_snps_chr;
	marker_record_t *simulation_records;

} hapsample_instance_t;

int hapsample_initialize (hapsample_instance_t * hs,
			  char *db_prefix,
			  char *user_snp_list_file, char *disease_model_file,
              char *output_directory,
			  double recombination_factor);
int hapsample_simulate_case_controls (hapsample_instance_t * hs,
				      int cases_cnt, int anticases_cnt);
int hapsample_simulate_trios (hapsample_instance_t * hs, int cnt);
void hapsample_cleanup (hapsample_instance_t * hs);
void record_print (marker_record_t * r, FILE * fp);
int get_record_by_snp_name (hapsample_instance_t * hs, marker_record_t * m,
			    char *name);

#define CASE_MODEL_FILENAME "disease_model_case.txt"
#define ANTICASE_MODEL_FILENAME "disease_model_anticase.txt"
#define TRIO_TRANS_MODEL_FILENAME "disease_model_trans_trio.txt"
#define TRIO_NONTRANS_MODEL_FILENAME "disease_model_nontrans_trio.txt"

int
  disease_load_models (hapsample_instance_t * hs, disease_model_t * case_model, disease_model_t
		       * anticase_model, char *user_disease_file, int trios);
void compute_probability_table (disease_model_t * dm, int samples_cnt);

/* added by Seunggeun Lee */
void 	WriteToLog( char *fmt, ... );

#endif
