/* ***************************************************************************

RENCI Open Source Software License
The University of North Carolina at Chapel Hill

The University of North Carolina at Chapel Hill (the "Licensor") through
its Renaissance Computing Institute (RENCI) is making an original work of
authorship (the "Software") available through RENCI upon the terms set
forth in this Open Source Software License (this "License").  This License
applies to any Software that has placed the following notice immediately
following the copyright notice for the Software:  Licensed under the RENCI
Open Source Software License v. 1.0.

Licensor grants You, free of charge, a world-wide, royalty-free,
non-exclusive, perpetual, sublicenseable license to do the following to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimers.

. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimers in the
documentation and/or other materials provided with the distribution.

. Neither You nor any sublicensor of the Software may use the names of
Licensor (or any derivative thereof), of RENCI, or of contributors to the
Software without explicit prior written permission.  Nothing in this
License shall be deemed to grant any rights to trademarks, copyrights,
patents, trade secrets or any other intellectual property of Licensor
except as expressly stated herein.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE CONTIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

You may use the Software in all ways not otherwise restricted or
conditioned by this License or by law, and Licensor promises not to
interfere with or be responsible for such uses by You.  This Software may
be subject to U.S. law dealing with export controls.  If you are in the
U.S., please do not mirror this Software unless you fully understand the
U.S. export regulations.  Licensees in other countries may face similar
restrictions.  In all cases, it is licensee's responsibility to comply
with any export regulations applicable in licensee's jurisdiction.

*************************************************************************** */
#include <string.h>
#include <stdlib.h>
#include "markers.h"
#include "util.h"

void
markers_free (markers_t * m)
{
	if (m->marker) {
		free (m->marker);
		free (m);
	}
}

void
add_marker (markers_t * markers, marker_info_t * m)
{
	markers->marker = (marker_info_t *) realloc (markers->marker,
						     (sizeof (marker_info_t) *
						      ((markers->cnt) + 1)));
	markers->marker[markers->cnt].name[0] = '\0';
	markers->marker[markers->cnt].type[0] = '\0';
	markers->marker[markers->cnt].primer[0] = '\0';
	strcpy (markers->marker[markers->cnt].name, m->name);
	strcpy (markers->marker[markers->cnt].type, m->type);
	strcpy (markers->marker[markers->cnt].primer, m->primer);
	markers->marker[markers->cnt].meioses = m->meioses;
	markers->marker[markers->cnt].heterozygosity = m->heterozygosity;
	markers->marker[markers->cnt].location = m->location;
	markers->marker[markers->cnt].sex_avg_pos = m->sex_avg_pos;
	markers->marker[markers->cnt].female_pos = m->female_pos;
	markers->marker[markers->cnt].male_pos = m->male_pos;
	markers->cnt++;
}

markers_t *
load_rutgers_markers_chr (const char *file)
{
	char line[1024], *p;
	FILE *fp;
	int lines = 0, j;
	marker_info_t m;
	markers_t *markers;
	int ignore;

	if ((fp = fopen (file, "r")) == NULL) {
		perror (file);
		return NULL;
	}
	markers = (markers_t *) malloc (sizeof (markers_t));
	markers->marker = NULL;
	markers->cnt = 0;

	while (fgets (line, sizeof (line), fp) != NULL) {
		/* skip header line */
		lines++;
		if (lines == 1)
			continue;
		p = line;
		ignore = 0;
		for (j = 0; j < 9; j++) {
			if ((p = strtok (p, "\t")) == NULL) {
				fprintf (stderr,
					 "WARNING: %s line %i: expected 9 fields\n",
					 file, lines);
				ignore = 1;
				break;
			}
			if (j == 0)
				strcpy (m.name, p);
			else if (j == 1)
				strcpy (m.type, p);
			else if (j == 2)
				strcpy (m.primer, p);
			else if (j == 3)
				m.meioses = atoi (p);
			else if (j == 4)
				m.heterozygosity = atof (p);
			else if (j == 5)
				m.location = atoi (p);
			else if (j == 6)
				m.sex_avg_pos = atof (p);
			else if (j == 7)
				m.female_pos = atof (p);
			else if (j == 8)
				m.male_pos = atof (p);
			p = NULL;
		}
		/* we are skipping SNP for now */
		if ((!strcmp (m.type, "SNP")) || (ignore))
			continue;
		/* add it to our list */
		add_marker (markers, &m);
	}
	fclose (fp);
	return markers;
}

int *
get_marker_locations (markers_t * m)
{
	int i;
	int *l;

	if ((l = (int *) malloc (sizeof (int) * m->cnt)) == NULL) {
		fprintf (stderr, "Error: out of memory (get_marker_loc)\n");
		return NULL;
	}
	for (i = 0; i < m->cnt; i++) {
		l[i] = m->marker[i].location;
	}
	return l;
}

int
write_markers (const char *fn, markers_t * markers)
{
	FILE *fp;
	int i;

	if ((fp = fopen (fn, "w")) == NULL) {
		perror (fn);
		return 10;
	}
	for (i = 0; i < markers->cnt; i++)
		fprintf (fp, "%i\n", markers->marker[i].location);
	fclose (fp);
	return 0;
}

void
marker_print (marker_info_t * m, FILE * fp)
{
	fprintf (fp, "%s\t%s\t%s\t%i\t%f\t%i\t%f\t%f\t%f\n",
		 m->name,
		 m->type,
		 m->primer,
		 m->meioses,
		 m->heterozygosity,
		 m->location, m->sex_avg_pos, m->female_pos, m->male_pos);
}

void
markers_print (markers_t * m, FILE * fp)
{
	int i;
	fprintf (fp, "markers_cnt\t%i\n", m->cnt);
	for (i = 0; i < m->cnt; i++)
		marker_print (&m->marker[i], fp);
}

markers_t **
load_rutgers_markers (const char *dir)
{
	int i;
	markers_t **m = (markers_t **) malloc (sizeof (markers_t *) * 22);
	for (i = 0; i < 22; i++) {
		char file[FILENAME_MAX];
		sprintf (file, "%s/rutgers_%i.map", dir, (i + 1));
		m[i] = load_rutgers_markers_chr (file);
	}
	return m;
}

double
get_max_genetic_location (markers_t ** markers, int chromosome)
{
	return markers[chromosome - 1]->marker[markers[chromosome - 1]->cnt -
					       1].sex_avg_pos;
}

double
get_genetic_location (markers_t * markers, char *snp_name, int snp_location)
{
	int start = 0, end = 0, i;
	double Mx, My;
	int x, y, z;

	if (markers->marker[0].location >= snp_location) {
		fprintf (stderr,
			 "%s:%i:genetic distance of %s[%i] falls before marker range of %i-%i, using 0.0\n",
			 __FILE__, __LINE__, snp_name, snp_location,
			 markers->marker[0].location,
			 markers->marker[markers->cnt - 1].location);
		return 0.0;
	}
	if (markers->marker[markers->cnt - 1].location < snp_location) {
		fprintf (stderr,
			 "%s:%i:genetic distance of %s[%i] falls after marker range of %i-%i, using max of %.12f\n",
			 __FILE__, __LINE__, snp_name, snp_location,
			 markers->marker[0].location,
			 markers->marker[markers->cnt - 1].location,
			 markers->marker[markers->cnt - 1].sex_avg_pos);
		return markers->marker[markers->cnt - 1].sex_avg_pos;
	}

	/* find two points around our location */
	for (i = 0; i < markers->cnt; i++) {
		if (markers->marker[i].location > snp_location) {
			start = markers->marker[i - 1].location;
			end = markers->marker[i].location;
			break;
		}
	}

	/* interpolate to get a reasonable value */
	Mx = markers->marker[i - 1].sex_avg_pos;
	My = markers->marker[i].sex_avg_pos;
	x = start;
	y = end;
	z = snp_location;
	return Mx + (My - Mx) * (z - x) / (y - x);
}

void
free_rutgers_markers (markers_t ** m)
{
	int i;
	for (i = 0; i < 22; i++) {
		if (m[i])
			markers_free (m[i]);
	}
	free (m);
}
