/* ***************************************************************************

RENCI Open Source Software License
The University of North Carolina at Chapel Hill

The University of North Carolina at Chapel Hill (the "Licensor") through
its Renaissance Computing Institute (RENCI) is making an original work of
authorship (the "Software") available through RENCI upon the terms set
forth in this Open Source Software License (this "License").  This License
applies to any Software that has placed the following notice immediately
following the copyright notice for the Software:  Licensed under the RENCI
Open Source Software License v. 1.0.

Licensor grants You, free of charge, a world-wide, royalty-free,
non-exclusive, perpetual, sublicenseable license to do the following to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimers.

. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimers in the
documentation and/or other materials provided with the distribution.

. Neither You nor any sublicensor of the Software may use the names of
Licensor (or any derivative thereof), of RENCI, or of contributors to the
Software without explicit prior written permission.  Nothing in this
License shall be deemed to grant any rights to trademarks, copyrights,
patents, trade secrets or any other intellectual property of Licensor
except as expressly stated herein.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE CONTIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

You may use the Software in all ways not otherwise restricted or
conditioned by this License or by law, and Licensor promises not to
interfere with or be responsible for such uses by You.  This Software may
be subject to U.S. law dealing with export controls.  If you are in the
U.S., please do not mirror this Software unless you fully understand the
U.S. export regulations.  Licensees in other countries may face similar
restrictions.  In all cases, it is licensee's responsibility to comply
with any export regulations applicable in licensee's jurisdiction.

*************************************************************************** */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <math.h>
#include <time.h>
#ifdef _WIN32
#include <windows.h>
#include <processthreadsapi.h>
#else
#include <unistd.h>
#include <libgen.h>
#endif
#include <string.h>
#include <stdlib.h>

#include "hapsample.h"
#include "util.h"
#include "markers.h"

static int preprocess (hapsample_instance_t * hs);

#define MEM() {fprintf(stderr, "out of memory!\n"); exit(1);}
static marker_record_t g_record;

#define CMP_RESET -9
static int g_lastcmp = CMP_RESET;

/*========================================================================*/


static int
disease_load (disease_model_t * dm, char *file)
{
	char line[1024];
	FILE *fp;
	int i, err;
	double total_prob = 0.0, curp = 0.0;

	if ((fp = fopen (file, "r")) == NULL) {
		perror (file);
		return 1;
	}
	dm->snp_name_cnt = 0;
	dm->prob_cnt = 0;
	dm->prob = NULL;
	dm->snp_names = NULL;
	if ((err = fscanf (fp, "%i\n", &dm->snp_name_cnt)) != 1) {
		perror (file);
		fclose (fp);
		return 1;
	}
	dm->snp_names = (char **) malloc (dm->snp_name_cnt * sizeof (char *));
	for (i = 0; i < dm->snp_name_cnt; i++) {
		if (fscanf (fp, "%s\n", line) != 1) {
			perror (file);
			fclose (fp);
			return 1;
		}
		dm->snp_names[i] = strdup (line);
	}
	dm->prob_cnt = (int) pow (3.0, (double) dm->snp_name_cnt);
	dm->prob = (double *) malloc (dm->prob_cnt * sizeof (double));
	dm->aprob = (double *) malloc (dm->prob_cnt * sizeof (double));
	for (i = 0; i < dm->prob_cnt; i++) {
		if (fscanf (fp, "%lf\n", &dm->prob[i]) != 1) {
			perror (file);
			fclose (fp);
			return 1;
		}
		if (dm->prob[i] < 0.0) {
			fprintf (stderr,
				 "error\nA disease model probability was negative.  Please modify your disease model");
			return 1;
		}
		total_prob += dm->prob[i];
	}

	/* normalize */
	for (i = 0; i < dm->prob_cnt; i++) {
		dm->prob[i] = dm->prob[i] / total_prob;
		curp += dm->prob[i];
		dm->aprob[i] = curp;
	}

	if (fabs (1.0 - total_prob) > 0.03) {
		fprintf (stderr,
			 "error\ndisease model probability must be within 0.03 of 1.0: %.8f",
			 total_prob);
		return 1;
	}

	fclose (fp);
	/* compute combination table */
	dm->combinations =
		build_combo_table (dm->snp_name_cnt, &dm->combinations_rows,
				   &dm->combinations_cols);

	return 0;
}

static void
disease_free (disease_model_t * dm)
{
	int i;
	if (dm->snp_names) {
		for (i = 0; i < dm->snp_name_cnt; i++)
			if (dm->snp_names[i])
				free (dm->snp_names[i]);
		free (dm->snp_names);
	}
	if (dm->prob)
		free (dm->prob);
	if (dm->aprob)
		free (dm->aprob);
	if (dm->combinations) {
		for (i = 0; i < dm->combinations_rows; i++)
			free (dm->combinations[i]);
		free (dm->combinations);
	}
	if (dm->probability_indices)
		free (dm->probability_indices);
	if (dm->records)
		free (dm->records);
}

void
compute_probability_table (disease_model_t * dm, int samples_cnt)
{
	int i;

	/* build probability indices */
	if ((dm->probability_indices = (int *) malloc (sizeof (int) *
						       samples_cnt)) ==
	    NULL) {
		printf ("mem\n");
		return;
	}
	for (i = 0; i < samples_cnt; i++) {
		int k;
		double dart;
		dart = rand_0_1 ();
		for (k = 0; k < dm->prob_cnt; k++) {
			if (dm->aprob[k] >= dart)
				break;
		}
		dm->probability_indices[i] = k;
	}
}

static int n_p[6] = { 1, 3, 9, 27, 81, 243 };

static int
disease_convert (hapsample_instance_t * hs, char *input_disease_file,
		 int trio)
{
	FILE *fp_in, *fp1_out, *fp2_out;
	char stream[50];
	int m, n, i, j, k;
	char **snps;
	double *maf;
	double pd1, pd1g0, pd1_true;
    char tmpFileName[FILENAME_MAX];
/* modified by Seunggeun Lee */
#define MAX_N 1024
	double pg[MAX_N], pgd1[MAX_N], pgd0[MAX_N], rrg[MAX_N], pd1g[MAX_N];
	if ((fp_in = fopen (input_disease_file, "r")) == NULL) {
		perror (input_disease_file);
		return 1;
	}
	if (trio) {
        sprintf(tmpFileName, "%s%s\0", hs->output_directory, TRIO_TRANS_MODEL_FILENAME);
		fp1_out = fopen (tmpFileName, "w");
        sprintf(tmpFileName, "%s%s\0", hs->output_directory, TRIO_NONTRANS_MODEL_FILENAME);
		fp2_out = fopen (tmpFileName, "w");
	}
	else {
        sprintf(tmpFileName, "%s%s\0", hs->output_directory, CASE_MODEL_FILENAME);
		fp1_out = fopen (tmpFileName, "w");
        sprintf(tmpFileName, "%s%s\0", hs->output_directory, ANTICASE_MODEL_FILENAME);
		fp2_out = fopen (tmpFileName, "w");
	}

	/*Determine how many disease snps */
	fscanf (fp_in, "%d", &m);
	fprintf (fp1_out, "%d\n", m);
	fprintf (fp2_out, "%d\n", m);
	snps = (char **) malloc (m * sizeof (char *));
	for (i = 0; i < m; i++)
		snps[i] = (char *) malloc (20 * sizeof (char));
	maf = (double *) malloc (m * sizeof (double));
	for (i = 0; i < m; i++) {
		marker_record_t record;
		fscanf (fp_in, "%s", snps[i]);
		/*fscanf (fp_in, "%s\t%f", snps[i], &maf[i]); */
#ifndef NO_REPLACE_DISEASE_MAF
		/* lookup actual maf for this snp from database and use that
		   value */
		if (get_record_by_snp_name (hs, &record, snps[i])) {
			/* no record for this snp */
			fprintf (stderr,
				 "error\nSNP %s not found in database\n",
				 snps[i]);
			fclose (fp_in);
			return 1;
		}
		maf[i] = record.minor_allele_frequency;
#endif
		fprintf (fp1_out, "%s\n", snps[i]);
		fprintf (fp2_out, "%s\n", snps[i]);
	}
	for (i = 0; i < m; i++)
		free (snps[i]);
	free (snps);

	fscanf (fp_in, "%lf", &pd1);
	/*Calculate pg */
	n = n_p[m];
	for (i = 0; i < n; i++) {
		pg[i] = 1.0;
		for (j = 0; j < m; j++) {
			if (j == 0)
				k = i % n_p[j + 1];
			else if (j == (m - 1)) {
				k = i / n_p[j];
			}
			else {
				k = i % n_p[j + 1];
				k = k / n_p[j];
			}
			if (k == 0)
				pg[i] *= (1.0 - maf[j]) * (1.0 - maf[j]);
			if (k == 1)
				pg[i] *= 2.0 * maf[j] * (1.0 - maf[j]);
			if (k == 2)
				pg[i] *= maf[j] * maf[j];
		}
	}
	free (maf);
	/*Three different disease models */
	fscanf (fp_in, "%s", stream);
	if (strcmp (stream, "AG") == 0) {
		for (i = 0; i < n; i++) {
			fscanf (fp_in, "%lf", &pgd1[i]);
			fprintf (fp1_out, "%f\n", pgd1[i]);
			if (trio) {
				fprintf (fp2_out, "%f\n", pg[i]);
			}
			else {
				pgd0[i] =
					(pg[i] - pgd1[i] * pd1) / (1.0 - pd1);
				fprintf (fp2_out, "%f\n", pgd0[i]);
			}
		}
		fflush (fp1_out);
		fclose (fp1_out);
		fflush (fp2_out);
		fclose (fp2_out);
		fclose (fp_in);
		return 0;
	}
	else if (strcmp (stream, "GRR") == 0) {
		pd1g0 = 0.0;
		for (i = 0; i < n; i++) {
			fscanf (fp_in, "%lf", &rrg[i]);
			pd1g0 += pg[i] * rrg[i] / pd1;
		}
		pd1g0 = 1.0 / pd1g0;
		for (i = 0; i < n; i++) {
			pgd1[i] = pg[i] * rrg[i] / pd1 * pd1g0;
			fprintf (fp1_out, "%f\n", pgd1[i]);
			if (trio) {
				fprintf (fp2_out, "%f\n", pg[i]);
			}
			else {
				pgd0[i] =
					(pg[i] - pgd1[i] * pd1) / (1.0 - pd1);
				fprintf (fp2_out, "%f\n", pgd0[i]);
			}
		}
		fflush (fp1_out);
		fclose (fp1_out);
		fflush (fp2_out);
		fclose (fp2_out);
		fclose (fp_in);
		return 0;
	}
	else if (strcmp (stream, "AR") == 0) {
		pd1_true = 0.0;
		for (i = 0; i < n; i++) {
			fscanf (fp_in, "%lf", &pd1g[i]);
			pd1_true += pd1g[i] * pg[i];
		}
		if ((pd1_true - pd1) > 1.e-10)
			printf ("Warning: pd1 (%f) does not equal to pd1.true (%f)\n", pd1, pd1_true);
		for (i = 0; i < n; i++) {
			pgd1[i] = pg[i] * pd1g[i] / pd1_true;
			fprintf (fp1_out, "%f\n", pgd1[i]);
			if (trio) {
				fprintf (fp2_out, "%f\n", pg[i]);
			}
			else {
				pgd0[i] =
					(pg[i] - pgd1[i] * pd1) / (1.0 - pd1);
				fprintf (fp2_out, "%f\n", pgd0[i]);
			}
		}
		fflush (fp1_out);
		fclose (fp1_out);
		fflush (fp2_out);
		fclose (fp2_out);
		fclose (fp_in);
		return 0;
	}
	fflush (fp1_out);
	fflush (fp2_out);
	fclose (fp1_out);
	fclose (fp2_out);
	fclose (fp_in);
	return 1;
}

int
disease_load_models (hapsample_instance_t * hs, disease_model_t * case_model,
		     disease_model_t * anticase_model,
		     char *user_disease_file, int trios)
{
	if (disease_convert (hs, user_disease_file, trios))
		return 1;
	if (trios) {
		if (disease_load (case_model, TRIO_TRANS_MODEL_FILENAME))
			return 1;
		if (disease_load
		    (anticase_model, TRIO_NONTRANS_MODEL_FILENAME))
			return 1;
	}
	else {
		if (disease_load (case_model, CASE_MODEL_FILENAME))
			return 1;
		if (disease_load (anticase_model, ANTICASE_MODEL_FILENAME))
			return 1;
	}
	return 0;
}

/*========================================================================*/

int
id_index_cmp (const void *a, const void *b)
{
	id_index_entry_t *x, *y;
	x = (id_index_entry_t *) a;
	y = (id_index_entry_t *) b;
	return strcmp (x->name, y->name);
}

int
get_db_sample (hapsample_instance_t * hs, marker_record_t * marker,
	       unsigned char *sample, int *global_record_index)
{
	id_index_entry_t key, *result;

	strcpy (key.name, marker->name);
	result = bsearch (&key, hs->id_index, hs->summary.record_cnt,
			  sizeof (id_index_entry_t), id_index_cmp);
	*global_record_index = result->record_num;
	/* read this row from disk */
	if (fseek
	    (hs->genotypes_fp, (result->record_num * hs->summary.sample_cnt),
	     SEEK_SET)) {
		fprintf (stderr, "fseek");
		perror (hs->genotypes_file);
		return 1;
	}
	if (fread
	    (&sample[0], sizeof (unsigned char), hs->summary.sample_cnt,
	     hs->genotypes_fp) != hs->summary.sample_cnt) {
		fprintf (stderr, "fread");
		perror (hs->genotypes_file);
		return 1;
	}
	return 0;
}

void *
xsearch (key, base0, nmemb, size, compar)
     register const void *key;
     const void *base0;
     size_t nmemb;
     register size_t size;
     register int (*compar) (const void *, const void *);
{
	register const char *base = base0;
	register size_t lim;
	register int cmp;
	register const void *p;
	for (lim = nmemb; lim != 0; lim >>= 1) {
		p = base + (lim >> 1) * size;
		cmp = (*compar) (key, p);
		if (g_lastcmp == CMP_RESET)
			g_lastcmp = cmp;
		else {
			if (g_lastcmp != cmp)
				return ((void *) p);
			g_lastcmp = cmp;
		}
		if (cmp == 0)
			return ((void *) p);
		if (cmp > 0) {	/* key > p: move right */
			base = (const char *) p + size;
			lim--;
		}		/* else move left */
	}
	return (NULL);
}

/*
get random starting point into genotype array
loop from that point over entire array (wrapping around as needed)
stop when you have first desired value (0,1,or don't care)
repeat for second value, stopping when combined values==genotype_total
*/
int
gen_random_sample (hapsample_instance_t * hs, marker_record_t * disease_snp,
		   int *genotypes, int genotype_total,
		   unsigned char *disease_sample)
{
	int which;

	for (which = 0; which < 2; which++) {
		/* randomly choose a sample (column) from database */
		int dart = rand_0_1 () * hs->summary.sample_cnt;
		int tries = 0;
		int done = 0, j;
		/* iterate over samples starting with the dart until we
		   find the combination of two samples that satisfy our 
		   requirements */
		for (j = dart;;) {
			int g = disease_sample[j];
			/*printf ("j=%i, which=%i, tries=%i, g=%i, total=%i\n",
			   j, which, tries, g, genotype_total);
			   fflush (stdout); */
			tries++;
			if (which == 0) {
				/* 
				   if total==2, we must have a 1 for both values
				 */
				if ((genotype_total == 0) && (g == 0))
					done = 1;
				else if ((genotype_total == 1)
					 && ((g == 0) || (g == 1)))
					done = 1;	/* break out of this loop */
				else if ((genotype_total == 2) && (g == 1))
					done = 1;
			}
			else {
				/* second sample.  If total == 2, we require
				   a 1.  If total==1 and we read a 0 in the first,
				   we require a one.  If total==0, we require a 
				   0
				 */
				if ((genotype_total == 0) && (g == 0))
					done = 1;
				else if (genotype_total == 1) {
					if ((((disease_sample[genotypes[0]] ==
					       1) && (g == 0)))
					    ||
					    ((disease_sample[genotypes[0]] ==
					      0) && (g == 1))) {
						done = 1;
					}
				}
				else if ((genotype_total == 2) && (g == 1))
					done = 1;
			}
			if (done == 1) {
				genotypes[which] = j;
				break;
			}
			if ((j + 1) == hs->summary.sample_cnt)
				j = 0;
			else
				j++;
			/* it's ok to re-use the original one */
			if (tries == (hs->summary.sample_cnt + 1)) {
				/* we've read through the whole genotype 
				   without breaking out, error.
				 */
				done = 2;
				break;
			}
		}
		if (done == 2) {
			/* failed to locate required first value */
			return 1;
		}
	}
	return 0;
}

void
summary_print (summary_t * s, FILE * fp)
{
	int chr;
	fprintf (fp, "%i.%i\n", s->version_high, s->version_low);
	fprintf (fp, "%i\n", s->record_cnt);
	fprintf (fp, "%i\n", s->sample_cnt);
	for (chr = 0; chr < 22; chr++) {
		fprintf (fp, "chr.%i.record_start\t%i\n", (chr + 1),
			 s->chromosome[chr].record_start);
		fprintf (fp, "chr.%i.record_cnt\t%i\n", (chr + 1),
			 s->chromosome[chr].record_cnt);
		fprintf (fp, "chr.%i.max_ldu\t%f\n", (chr + 1),
			 s->chromosome[chr].max_ldu);
		fprintf (fp, "chr.%i.min_ldu\t%f\n", (chr + 1),
			 s->chromosome[chr].min_ldu);
	}
}

void
record_print (marker_record_t * r, FILE * fp)
{
	fprintf (fp, "%s\t%i\t%i\t%.12f\t%.12f\t%.12f",
		 r->name,
		 r->chromosome,
		 r->location,
		 r->minor_allele_frequency,
		 r->linkage_disequalibrium, r->genetic_location);
}

int
summary_load (hapsample_instance_t * hs)
{
	FILE *summary_fp;
	char buf[1024];

	if ((summary_fp = fopen (hs->summary_file, "r")) == NULL) {
		perror (hs->summary_file);
		return 1;
	}

	while (fgets (buf, sizeof (buf), summary_fp) != NULL) {
		char name[1024], val[1024], *p;

		sscanf (buf, "%s\t%s", name, val);
		if (!strcmp (name, "version")) {
			p = strtok (val, ".");
			hs->summary.version_high = atoi (p);
			p = strtok (NULL, ".");
			hs->summary.version_low = atoi (p);
		}
		else if (!strcmp (name, "record_cnt"))
			hs->summary.record_cnt = atoi (val);
		else if (!strcmp (name, "sample_cnt"))
			hs->summary.sample_cnt = atoi (val);
		else if (!strncmp (name, "chr.", 4)) {
			int chr;
			p = strtok (name, ".");
			p = strtok (NULL, ".");
			chr = atoi (p);
			p = strtok (NULL, ".");
			if (!strcmp (p, "record_start"))
				hs->summary.chromosome[chr - 1].record_start =
					atoi (val);
			else if (!strcmp (p, "record_cnt"))
				hs->summary.chromosome[chr - 1].record_cnt =
					atoi (val);
			else if (!strcmp (p, "max_ldu"))
				hs->summary.chromosome[chr - 1].max_ldu =
					atof (val);
			else if (!strcmp (p, "min_ldu"))
				hs->summary.chromosome[chr - 1].min_ldu =
					atof (val);
		}
	}
	fclose (summary_fp);
	return 0;
}

int
has_record (hapsample_instance_t * hs, char *name)
{
	id_index_entry_t key, *result;

	strcpy (key.name, name);
	if ((result = bsearch (&key, hs->id_index, hs->summary.record_cnt,
			       sizeof (id_index_entry_t),
			       id_index_cmp)) == NULL)
		return 0;
	return 1;
}

int
get_record_by_snp_name (hapsample_instance_t * hs, marker_record_t * m,
			char *name)
{
	id_index_entry_t key, *result;
	strcpy (key.name, name);
	if ((result = bsearch (&key, hs->id_index, hs->summary.record_cnt,
			       sizeof (id_index_entry_t),
			       id_index_cmp)) == NULL) {
		printf ("Key not found: %s\n", name);
		return 1;
	}
	if (fseek
	    (hs->records_fp, (RECORD_SIZE * result->record_num), SEEK_SET)) {
		perror ("y");
		return 1;
	}
	if (fread (m->name, sizeof (m->name), 1, hs->records_fp) != 1) {
		perror (hs->records_file);
		return 1;
	}
	if (fread (&m->chromosome, sizeof (m->chromosome), 1, hs->records_fp)
	    != 1) {
		perror (hs->records_file);
		return 1;
	}
	if (fread (&m->location, sizeof (m->location), 1, hs->records_fp) !=
	    1) {
		perror (hs->records_file);
		return 1;
	}
	if (fread (&m->minor_allele_frequency,
		   sizeof (m->minor_allele_frequency), 1,
		   hs->records_fp) != 1) {
		perror (hs->records_file);
		return 1;
	}
	if (fread (&m->linkage_disequalibrium,
		   sizeof (m->linkage_disequalibrium), 1,
		   hs->records_fp) != 1) {
		perror (hs->records_file);
		return 1;
	}
	if (fread (&m->genetic_location,
		   sizeof (m->genetic_location), 1, hs->records_fp) != 1) {
		perror (hs->records_file);
		return 1;
	}
	return 0;
}

int
load_id_index (hapsample_instance_t * hs)
{
	FILE *fp;
	if ((fp = fopen (hs->id_index_file, "rb")) == NULL) {
		perror (hs->id_index_file);
		return 1;
	}
	hs->id_index =
		(id_index_entry_t *) malloc (hs->summary.record_cnt *
					     sizeof (id_index_entry_t));
	if (!hs->id_index)
		MEM ();

	if (fread
	    (hs->id_index, sizeof (id_index_entry_t), hs->summary.record_cnt,
	     fp) != hs->summary.record_cnt) {
		perror (hs->id_index_file);
		free (hs->id_index);
		fclose (fp);
		return 1;
	}
	fclose (fp);
	return 0;
}

/* all records assumed to exist */
int
get_marker_records (hapsample_instance_t * hs, char **snp_names,
		    int snp_name_cnt, marker_record_t * records)
{
	int i;
	for (i = 0; i < snp_name_cnt; i++) {
		if (get_record_by_snp_name (hs, &(records[i]), snp_names[i])) {
			printf ("Panic, record %s assumed to exist!\n",
				snp_names[i]);
			exit (1);
		}
	}
	return 0;
}

int
get_marker_records_with_missing (hapsample_instance_t * hs, char **snp_names,
				 int snp_name_cnt, marker_record_t ** records,
				 int *missing_cnt, int **missing_indices)
{
	int i;
	*missing_indices = NULL;
	*missing_cnt = 0;
	for (i = 0; i < snp_name_cnt; i++) {
		if (get_record_by_snp_name (hs, &g_record, snp_names[i])) {
			(*missing_cnt)++;
			*missing_indices = (int *) realloc (*missing_indices,
							    sizeof (int) *
							    (*missing_cnt));
			*missing_indices[(*missing_cnt) - 1] = i;
			continue;
		}
		record_print (&g_record, stdout);
		fprintf (stdout, "\n");
	}
	return 0;
}


int
validate_disease_model (hapsample_instance_t * hs, disease_model_t * model)
{
	int i;
	/* ensure all SNPs are available */
	for (i = 0; i < model->snp_name_cnt; i++) {
		if (!has_record (hs, model->snp_names[i])) {
			printf ("Error: disease SNP not found: %s\n",
				model->snp_names[i]);
			return 1;
		}
	}
	/* yup, grab them all */
	model->records =
		(marker_record_t *) malloc (sizeof (marker_record_t) *
					    model->snp_name_cnt);
	if (!model->records)
		MEM ();

	get_marker_records (hs, model->snp_names, model->snp_name_cnt,
			    model->records);

	for (i = 0; i < 22; i++)
		model->chr_to_record_index[i] = -1;
	for (i = 0; i < model->snp_name_cnt; i++) {
		/* there can only be one snp/chromosome */
		if (model->
		    chr_to_record_index[model->records[i].chromosome - 1] !=
		    -1) {
			fprintf (stderr,
				 "Error, only one SNP/chromosome allowed\n");
			return 1;
		}

		model->chr_to_record_index[model->records[i].chromosome - 1] =
			i;

		/* the minor allele frequency must be > 0 for disease SNPs */
		if (model->records[i].minor_allele_frequency == 0.0) {
			fprintf (stderr,
				 "Error, disease minor allele frequency must be > 0.0\n");
			return 1;
		}
	}

	return 0;
}

int
load_disease_models (hapsample_instance_t * hs)
{
	int is_trio = hs->user_prefs.simulation_type == TRIOS ? 1 : 0;
	if (disease_load_models
	    (hs, &hs->case_disease_model, &hs->anticase_disease_model,
	     hs->user_prefs.disease_model_file, is_trio))
		return 1;

	if (validate_disease_model (hs, &hs->case_disease_model))
		return 1;
	if (validate_disease_model (hs, &hs->anticase_disease_model))
		return 1;

	return 0;
}

/* Modified by Seunggeun Lee */
int
remove_unknown_snps (hapsample_instance_t * hs)
{
	int i, new_list_cnt = 0 ,is_start= 0;
	char **new_list =
		(char **) malloc (sizeof (char *) * hs->user_prefs.snp_cnt);
	if (!new_list)
		MEM ();

	for (i = 0; i < hs->user_prefs.snp_cnt; i++) {
		if (has_record (hs, hs->user_prefs.snp_list[i]))
			new_list[new_list_cnt++] =
				strdup (hs->user_prefs.snp_list[i]);
		else {
			hs->summary.unknown_snp_cnt++;
			/*free (hs->user_prefs.snp_list[i]); */
			if(is_start == 0){
				WriteToLog("\n************ SNPs not found in database ************\n\n"); 
			}
			WriteToLog("%s\n",hs->user_prefs.snp_list[i]);
			is_start = 1;
		}
	}
	
	if(is_start == 1){
		WriteToLog("\n*************** END_LIST ******************\n\n"); 
	}


	new_list =
		(char **) realloc (new_list, sizeof (char *) * new_list_cnt);
	free_strings (hs->user_prefs.snp_list, hs->user_prefs.snp_cnt);
	hs->user_prefs.snp_cnt = new_list_cnt;
	hs->user_prefs.snp_list = new_list;
	return 0;
}

static int
cmplocationp (const void *p1, const void *p2)
{
	marker_record_t *a = (marker_record_t *) p1;
	marker_record_t *b = (marker_record_t *) p2;
	if (a->location < b->location)
		return -1;
	else if (a->location > b->location)
		return 1;
	return 0;
}

static int
cmpchromosomep (const void *p1, const void *p2)
{
	marker_record_t *a = (marker_record_t *) p1;
	marker_record_t *b = (marker_record_t *) p2;
	if (a->chromosome < b->chromosome)
		return -1;
	else if (a->chromosome > b->chromosome)
		return 1;
	return 0;
}

static int
cmpstringp (const void *p1, const void *p2)
{
	return strcmp (*(char *const *) p1, *(char *const *) p2);
}

int
load_user_snps (hapsample_instance_t * hs)
{
	/*
	   The user supplies a list of SNP names.  We need to:
	   load list of names
	   keep only those which we have in our database
	   sort the list for rapid access later
	 */
	/* load the SNP names from disk */
	hs->user_prefs.snp_cnt = 1024;
	if ((hs->user_prefs.snp_list =
	     load_strings (hs->user_prefs.snp_list_file, 64,
			   &hs->user_prefs.snp_cnt)) == NULL) {
		return 1;
	}

	/* only keep ones we have in our database */
	remove_unknown_snps (hs);

	/* sort */
	qsort (&hs->user_prefs.snp_list[0], hs->user_prefs.snp_cnt,
	       sizeof (char *), cmpstringp);
	return 0;
}

/**
Copy a contiguous segment of markers from one sample to another based on a
given LDU range.

The actual markers to copy are derived from the given LDU range.  Assumes SNPs 
are sorted by physical location in order to assure LDU mapping
*/
int
copy_sample_segment (hapsample_instance_t * hs, int chromosome,
		     unsigned char **src_samples, int src_sample_index,
		     unsigned char **new_samples, int target_sample,
		     double ldu_start, double ldu_end, int *start_ldu_index)
{
	int i, seg_start = -1, seg_end = 0,
		state = 0,
		done = 0, src_snps_cnt =
		hs->simulation_snps_cnt[chromosome - 1];
	int src_snps_start = hs->simulation_snps_index[chromosome - 1];
	seg_start = -1;
	seg_end = 0;

	/* map from LDU range to SNP range */
	for (i = *start_ldu_index; (i < src_snps_cnt) && (!done); i++) {
		marker_record_t *record;
		record = &hs->simulation_records[src_snps_start + i];
		if (state == 0) {
			if ((record->linkage_disequalibrium >= ldu_start) &&
			    (record->linkage_disequalibrium < ldu_end)) {
				seg_start = i;
				state = 1;
			}
		}
		else {
			if ((record->linkage_disequalibrium > ldu_end)
			    || ((i + 1) == src_snps_cnt)) {
				if ((record->linkage_disequalibrium > ldu_end)
				    && ((i + 1) == src_snps_cnt)) {
					seg_end = i - 1;
				}
				else if (record->linkage_disequalibrium >
					 ldu_end) {
					seg_end = i - 1;
				}
				else {
					seg_end = i;
				}
				done = 1;
			}
		}
	}
	/* did we run to the end or did we find none (which is valid)? */
	if ((done == 0) && (i == src_snps_cnt) && (seg_start != -1)) {
		/* use last one */
		seg_end = i - 1;
		*start_ldu_index = i;
	}
	else if (done == 0) {
		/* none fit */
		return 1;
	}
	*start_ldu_index = seg_end + 1;
	/* we have a mapping, now do the actual copy */
	/*printf ("SEGMENT: %i - %i (src_sample=%i, new_sample=%i)\n",
	   seg_start, seg_end, src_sample_index, target_sample); */
	for (i = seg_start; i <= seg_end; i++) {
		new_samples[i][target_sample] =
			src_samples[i][src_sample_index];
	}
	return 0;
}

static unsigned char **g_samples = NULL;

unsigned char **
load_db_samples (hapsample_instance_t * hs, int chromosome)
{
	int i;
	int sample_cnt = hs->summary.sample_cnt;
	int src_snps_start = hs->simulation_snps_index[chromosome - 1];

	/* 
	   allocate a matrix large enough to hold data for the individual
	   chromosome with the largest number of SNPs and reuse this memory
	   for all chromosomes
	 */
	if (g_samples == NULL) {
		if ((g_samples =
		     (unsigned char **) malloc (hs->max_snps *
						sizeof (unsigned char *))) ==
		    NULL) {
			fprintf (stderr, "Out of memory: %s:%i\n", __FILE__,
				 __LINE__);
			exit (1);
		}
		for (i = 0; i < hs->max_snps; i++) {
			g_samples[i] = (unsigned char *)
				malloc (sizeof (unsigned char) * sample_cnt);
			if (!g_samples[i])
				MEM ();
		}
	}
	/*

	 */
	for (i = 0; i < hs->simulation_snps_cnt[chromosome - 1]; i++) {
		marker_record_t *sim_rec =
			&hs->simulation_records[src_snps_start + i];
		id_index_entry_t key, *result;

		strcpy (key.name, sim_rec->name);
		result = bsearch (&key, hs->id_index, hs->summary.record_cnt,
				  sizeof (id_index_entry_t), id_index_cmp);

		/* read this row from disk */
		if (fseek
		    (hs->genotypes_fp, (result->record_num * sample_cnt),
		     SEEK_SET)) {
			fprintf (stderr, "fseek");
			perror (hs->genotypes_file);
			return NULL;
		}
		if (fread
		    (g_samples[i], sizeof (unsigned char), sample_cnt,
		     hs->genotypes_fp) != sample_cnt) {
			fprintf (stderr, "fread");
			perror (hs->genotypes_file);
			return NULL;
		}
	}
	return g_samples;
}

int
simulate_normal_samples (hapsample_instance_t * hs,
			 unsigned char **db_samples, int chromosome,
			 unsigned char **new_samples, int nSample)
{
	int *recombinations, sample, sample_cnt = nSample, i, trace = 0;
	double max_genetic_loc, seed, max_ldu, min_ldu;
	char trace_file[FILENAME_MAX];
	int trace_sample_cnt = sample_cnt > 50 ? 50 : sample_cnt;
	FILE *fp;

	/* As experiment, we'll create a trace file for only the chromosome
	   with most number of SNPs.  Is that this chromosome?
	 */
	if (chromosome == hs->max_snps_chr)
		trace = 1;

	max_ldu = hs->summary.chromosome[chromosome - 1].max_ldu;
	min_ldu = hs->summary.chromosome[chromosome - 1].min_ldu;
	/* this is to hold the new samples for each snp in this chromosome */

	max_genetic_loc =
		get_max_genetic_location (hs->rutgers_markers, chromosome);
	seed = max_genetic_loc * hs->recombination_factor;
	recombinations = gen_poisson_nums (seed, sample_cnt);

	if (trace) {
		sprintf (trace_file, "%i_normal_trace.dat", chromosome);
		fp = fopen (trace_file, "w");
		fprintf (fp, "min_ldu\t%.12f\n", min_ldu);
		fprintf (fp, "max_ldu\t%.12f\n", max_ldu);
		fprintf (fp, "sample_cnt\t%i\n", trace_sample_cnt);
		fprintf (fp, "max_genetic_location\t%.12f\n",
			 max_genetic_loc);
		fprintf (fp, "seed\t%.12f\n", seed);
		fprintf (fp, "recombinations\t");
		for (i = 0; i < sample_cnt; i++) {
			fprintf (fp, "%i", recombinations[i]);
			if ((i + 1) < sample_cnt)
				fprintf (fp, " ");
		}
		fprintf (fp, "\n");
		fflush (fp);
	}

	for (sample = 0; sample < sample_cnt; sample++) {
		double *ldu_map;
		int j, interval_cnt = recombinations[sample],
			ldu_map_cnt = interval_cnt + 2, start_ldu_idx;
		if ((ldu_map =
		     (double *) malloc (sizeof (double) * ldu_map_cnt)) ==
		    NULL) {
			MEM ();
			exit (1);
		}
		ldu_map[0] = min_ldu;
		ldu_map[ldu_map_cnt - 1] = max_ldu;
		for (j = 1; j < ldu_map_cnt - 1; j++)
			ldu_map[j] = (rand_0_1 () * max_ldu);
		qsort (ldu_map, (interval_cnt + 2), sizeof (double),
		       cmpdoublep);
		/* at this point, we need a way to map these artificial LDU values to their real counterparts */
		if (trace && sample < trace_sample_cnt) {
			fprintf (fp, "sample\t%i\n", sample);
			fprintf (fp, "ldu_map\t");
			for (j = 1; j < ldu_map_cnt - 1; j++) {
				fprintf (fp, "%.12f", ldu_map[j]);
				if ((j + 1) < ldu_map_cnt)
					fprintf (fp, " ");
			}
			fprintf (fp, "\n");
		}

		start_ldu_idx = 0;
		for (j = 0; j < ldu_map_cnt - 1; j++) {
			int src_sample;
			double ldu_start, ldu_end, ldu_segment;

			/* randomly choose sample from which to copy segment */
			src_sample = rand_0_1 () * hs->summary.sample_cnt;

			/* determine the actual segment to copy based on ldu */
			ldu_start = ldu_map[j];
			ldu_end = ldu_map[j + 1];
			ldu_segment = ldu_end - ldu_start;
			if ((trace) && (sample < trace_sample_cnt)) {
				fprintf (fp, "src_sample\t%i\n", src_sample);
				fprintf (fp, "ldu_start\t%.12f\n", ldu_start);
				fprintf (fp, "ldu_end\t%.12f\n", ldu_end);
				fprintf (fp, "ldu_segment_len\t%.12f\n",
					 ldu_segment);
			}
			/* copy all snps with ldu values between ldu_start
			   and ldu_end */
			copy_sample_segment (hs, chromosome, db_samples,
					     src_sample, new_samples,
					     sample, ldu_start,
					     ldu_end, &start_ldu_idx);
		}
		free (ldu_map);
	}
	free (recombinations);
	if (trace)
		fclose (fp);

	return 0;
}

double *
gen_recombination_points (int map_cnt, double min_ldu_value, double
			  max_ldu_value)
{
	double *map;
	int j, cnt = 0;
	if ((map = (double *) malloc (sizeof (double) * map_cnt)) == NULL)
		MEM ();

	map[0] = min_ldu_value;
	map[map_cnt - 1] = max_ldu_value;
	for (j = 1; j < map_cnt - 1;) {
		double range;
		if (cnt++ >= 1000) {
			fprintf (stderr,
				 "Panic, too many attempts to find random number within range\n");
			fprintf (stderr,
				 "map_cnt=%i, map[j]=%.12f, min_ldu_value=%.12f, max_ldu_value=%.12f\n",
				 map_cnt, map[j], min_ldu_value,
				 max_ldu_value);
			exit (1);
		}
		range = max_ldu_value - min_ldu_value;
		if (range == 0.0) {
			map[j] = max_ldu_value;
			break;
		}
		else {
			double b = rand_0_1 () * range;
			map[j] = min_ldu_value + b;
		}
		if (map[j] >= min_ldu_value) {
			cnt = 0;
			j++;
		}
	}
	/* sort the offsets */
	qsort (map, map_cnt, sizeof (double), cmpdoublep);
	return map;
}

int
new_diseased_sample (hapsample_instance_t * hs, unsigned char **db_samples,
		     int chromosome, unsigned char **new_samples,
		     int new_sample_index, marker_record_t * disease_snp,
		     int num_upper_recombinations,
		     int num_lower_recombinations,
		     double min_ldu_for_this_chromosome,
		     double max_ldu_for_this_chromosome, int sample_column)
{
	int which;
	double min_ldu, max_ldu, disease_seg_start, disease_seg_end;
	int src_sample, start_ldu_index = 0;
	double ldu_start, ldu_end;
	/* we now have what we need to generate two diseased
	   SNP samples and combine them. Do upper then lower */
	for (which = 0; which < 2; which++) {
		int interval_cnt, map_cnt, j;
		double *map;
		if (which == 0) {
			interval_cnt = num_upper_recombinations;
			min_ldu = min_ldu_for_this_chromosome;
			max_ldu = disease_snp->linkage_disequalibrium;
		}
		else {
			interval_cnt = num_lower_recombinations;
			min_ldu = disease_snp->linkage_disequalibrium;
			max_ldu = max_ldu_for_this_chromosome;
		}
		map_cnt = interval_cnt + 2;
		map = gen_recombination_points (map_cnt, min_ldu, max_ldu);
		if (which == 0)
			disease_seg_start = map[map_cnt - 2];
		else
			disease_seg_end = map[1];
		start_ldu_index = 0;
		for (j = 0; j < map_cnt - 1; j++) {

			/* determine the actual segment to copy */
			src_sample = rand_0_1 () * hs->summary.sample_cnt;
			ldu_start = map[j];
			ldu_end = map[j + 1];
			/* copy all snps with ldu values between ldu_start
			   and ldu_end */
			copy_sample_segment (hs, chromosome, db_samples,
					     src_sample, new_samples,
					     sample_column, ldu_start,
					     ldu_end, &start_ldu_index);
		}
		free (map);
	}
	/* now overlay our source sample segment in the middle */
	start_ldu_index = 0;
	copy_sample_segment (hs, chromosome, db_samples, new_sample_index,
			     new_samples, sample_column, disease_seg_start,
			     disease_seg_end, &start_ldu_index);

	return 0;
}

/* Modified by Seunggeun Lee */
void
write_samples (hapsample_instance_t * hs, int chromosome,
	       FILE * haplotypes_fp, FILE * genotypes_fp,
	       unsigned char **new_samples, int nSample)
{
	int i, x;
	FILE *fps[2];
	fps[0] = haplotypes_fp;
	fps[1] = genotypes_fp;
	for (i = 0; i < hs->simulation_snps_cnt[chromosome - 1]; i++) {
		int j;
		int record_index =
			hs->simulation_snps_index[chromosome - 1] + i;
		for (x = 0; x < 2; x++)
			fprintf (fps[x], "%i\t%s\t%i\t%.12f\t", chromosome,
				 hs->simulation_records[record_index].name,
				 hs->simulation_records[record_index].
				 location,
				 hs->simulation_records[record_index].
				 minor_allele_frequency);
		/* haplotypes */
		for (j = 0; j < nSample; j++) {
			fprintf (haplotypes_fp, "%i", new_samples[i][j]);
			if ((j + 1) < nSample)
				fprintf (haplotypes_fp, "\t");
		}
		/* genotypes */
		for (j = 0; j < nSample; j += 2) {
			fprintf (genotypes_fp, "%i",
				 (new_samples[i][j] + new_samples[i][j + 1]));
			if ((j + 2) < nSample)
				fprintf (genotypes_fp, "\t");
		}
		for (x = 0; x < 2; x++)
			fprintf (fps[x], "\n");
	}
}
static unsigned char **g_new_samples = NULL;

/* Modified by Seunggeun Lee */
int simulate_set (hapsample_instance_t * hs, disease_model_t * disease,
	      char *haplotypes_filename, char *genotypes_filename, int nSample , int nMaxSample)
{
	int i, c, *upper_recombinations, *lower_recombinations, sample;
	FILE *haplotypes_fp, *genotypes_fp;
	marker_record_t *disease_snp;
	double genetic_location, max_genetic_location, upper_seed, lower_seed;
	unsigned char *disease_sample =
		(unsigned char *) malloc (hs->summary.sample_cnt);
	unsigned char **db_samples;
	int disease_snp_index_on_chr;
	int disease_snp_global_index;
    char tmpFileName[FILENAME_MAX];

	genotypes_fp = fopen (genotypes_filename, "w");
	haplotypes_fp = fopen (haplotypes_filename, "w");

	if (!disease_sample)
		MEM ();

	if (g_new_samples == NULL) {
		if ((g_new_samples =
		     (unsigned char **) malloc (hs->max_snps *
						sizeof (unsigned char *))) ==
		    NULL) {
			fprintf (stderr, "Out of memory: %s:%i\n", __FILE__,
				 __LINE__);
			exit (1);
		}
		for (i = 0; i < hs->max_snps; i++) {
			if ((g_new_samples[i] = (unsigned char *)
			     malloc (sizeof (unsigned char) * nMaxSample)) == NULL) {
				fprintf (stderr, "Out of memory!\n");
				exit (1);
			}
			memset (g_new_samples[i], 'X', nMaxSample);
		}
	}

	for (i = 0; i < 22; i++) {
		int xx;
		int chr_snps_start = hs->simulation_snps_index[i];

		/* load database snps for this chromosome */
		double min_ldu_for_this_chromosome =
			hs->summary.chromosome[i].min_ldu;
		double max_ldu_for_this_chromosome =
			hs->summary.chromosome[i].max_ldu;

		db_samples = load_db_samples (hs, (i + 1));

		/* helps sanity check to clear all new samples to X */
		for (xx = 0; xx < hs->max_snps; xx++) {
			memset (g_new_samples[xx], 'X', nMaxSample);
		}
		if (hs->simulation_snps_index[i] < 0) {
			/* no SNPs to simulate on this chromosome */
			continue;
		}
		/* we simulate differently if disease snp v. non-disease */
		if ((c = disease->chr_to_record_index[i]) == -1) {
			/* no disease SNP on this chromosome */
			simulate_normal_samples (hs, db_samples, (i + 1),
						 g_new_samples,nSample);
			write_samples (hs, (i + 1), haplotypes_fp,
				       genotypes_fp, g_new_samples,nSample);
			continue;
		}

		/* there is a disease SNP on this chromosome */
		disease_snp_index_on_chr = -1;
		disease_snp = &disease->records[c];
		for (xx = 0; xx < hs->simulation_snps_cnt[i]; xx++) {
			int index = chr_snps_start + xx;
			if (!strcmp
			    (hs->simulation_records[index].name,
			     disease_snp->name)) {
				disease_snp_index_on_chr = xx;
				break;
			}
		}
		if (disease_snp_index_on_chr == -1) {
			printf ("Error\nPANIC!  Didn't find snp by name\n");
			exit (1);
		}

		/* get sample data for the disease snp */
		get_db_sample (hs, disease_snp, disease_sample,
			       &disease_snp_global_index);
		genetic_location =
			get_genetic_location (hs->rutgers_markers[i],
					      disease_snp->name,
					      disease_snp->location);
		max_genetic_location =
			get_max_genetic_location (hs->rutgers_markers,
						  (i + 1));
		upper_seed = genetic_location * hs->recombination_factor;
		upper_recombinations =
			gen_poisson_nums (upper_seed, nSample);
		lower_seed =
			(max_genetic_location -
			 genetic_location) * hs->recombination_factor;
		lower_recombinations =
			gen_poisson_nums (lower_seed, nSample);
		for (sample = 0; sample < (nSample / 2); sample++) {
			int combo_offset, total, prob_offset;
			int sample_indices_to_use[2];
			prob_offset = disease->probability_indices[sample];
			for (combo_offset = 0;
			     combo_offset < disease->snp_name_cnt;
			     combo_offset++)
				if (!strcmp
				    (disease_snp->name,
				     disease->records[combo_offset].name))
					break;
			total = disease->
				combinations[prob_offset][combo_offset];
			gen_random_sample (hs, disease_snp,
					   sample_indices_to_use, total,
					   disease_sample);
			if (total != (db_samples[disease_snp_index_on_chr]
				      [sample_indices_to_use[0]] +
				      db_samples[disease_snp_index_on_chr]
				      [sample_indices_to_use[1]])) {
				printf ("Error\nACK: PANIC: DON'T ADD UP; db_samples[%i][%i,%i]=%i,%i should add to %i\n", disease_snp_index_on_chr, sample_indices_to_use[0], sample_indices_to_use[1], db_samples[disease_snp_index_on_chr][sample_indices_to_use[0]], db_samples[disease_snp_index_on_chr][sample_indices_to_use[1]], total);
				printf ("%s:\n",
					hs->
					simulation_records[chr_snps_start +
							   disease_snp_index_on_chr].
					name);
				for (xx = 0; xx < hs->summary.sample_cnt;
				     xx++)
					printf ("%i\t",
						db_samples
						[disease_snp_index_on_chr]
						[xx]);
				printf ("\n");
			}
			new_diseased_sample (hs, db_samples, (i + 1),
					     g_new_samples,
					     sample_indices_to_use[0],
					     disease_snp,
					     upper_recombinations[sample*2],
					     lower_recombinations[sample*2],
					     min_ldu_for_this_chromosome,
					     max_ldu_for_this_chromosome,
					     (sample * 2));

			new_diseased_sample (hs, db_samples, (i + 1),
					     g_new_samples,
					     sample_indices_to_use[1],
					     disease_snp,
					     upper_recombinations[sample*2+1],
					     lower_recombinations[sample*2+1],
					     min_ldu_for_this_chromosome,
					     max_ldu_for_this_chromosome,
					     (sample * 2) + 1);
			fflush (stdout);
			/*
			WriteToLog("%d %d %d %d\n",upper_recombinations[sample*2],
			upper_recombinations[sample*2+1],
			lower_recombinations[sample*2],
			lower_recombinations[sample*2+1]);
			*/

			if (total != (g_new_samples[disease_snp_index_on_chr]
				      [(sample * 2)] +
				      g_new_samples[disease_snp_index_on_chr][(sample * 2) + 1])) {
				printf ("Error\nPANIC: DON'T ADD UP; new_samples[%i][%i,%i]=%i,%i should add to %i\n", disease_snp_index_on_chr, (sample * 2), ((sample * 2) + 1), g_new_samples[disease_snp_index_on_chr][(sample * 2)], g_new_samples[disease_snp_index_on_chr][(sample * 2) + 1], total);
			}
			fflush (stdout);

		}
		if (upper_recombinations)
			free (upper_recombinations);
		if (lower_recombinations)
			free (lower_recombinations);
		write_samples (hs, (i + 1), haplotypes_fp, genotypes_fp,
			       g_new_samples , nSample);
	}

	free (disease_sample);
	fclose (haplotypes_fp);
	fclose (genotypes_fp);
	return 0;
}

int
write_trios (hapsample_instance_t * hs)
{
	int row;

	/* derived from case and anticase haplotypes previously generated */
	FILE *case_fp, *anticase_fp, *trio_hap_fp, *trio_gen_fp;

	if ((trio_gen_fp = fopen (hs->trio_genotypes_filename, "w")) == NULL) {
		perror (hs->trio_genotypes_filename);
		return 1;
	}
	if ((trio_hap_fp = fopen (hs->trio_haplotypes_filename, "w")) == NULL) {
		perror (hs->trio_haplotypes_filename);
		return 1;
	}
	if ((case_fp = fopen (hs->case_haplotypes_filename, "r")) == NULL) {
		perror (hs->case_haplotypes_filename);
		return 1;
	}
	if ((anticase_fp =
	     fopen (hs->anticase_haplotypes_filename, "r")) == NULL) {
		perror (hs->case_haplotypes_filename);
		return 1;
	}
	for (row = 0; row < hs->simulation_snp_cnt; row++) {
		int chr, location, sample;
		char name[MAX_SNP_NAME_LEN];
		double maf;
		fscanf (case_fp, "%i\t%s\t%i\t%lf\t", &chr, name, &location,
			&maf);
		fprintf (trio_hap_fp, "%i\t%s\t%i\t%.12f\t", chr, name,
			 location, maf);
		fscanf (anticase_fp, "%i\t%s\t%i\t%lf\t", &chr, name,
			&location, &maf);
		fprintf (trio_gen_fp, "%i\t%s\t%i\t%.12f\t", chr, name,
			 location, maf);
		for (sample = 0; sample < hs->cases_cnt; sample += 2) {
			int m, p, c0, c1;
			fscanf (anticase_fp, "%i\t%i", &m, &p);
			fscanf (case_fp, "%i\t%i", &c0, &c1);
			fprintf (trio_hap_fp, "%i\t%i\t%i\t%i\t", m, c0, c1,
				 p);
			fprintf (trio_gen_fp, "%i\t%i\t%i\t", m + c0, c0 + c1,
				 c1 + p);
		}
		fprintf (trio_hap_fp, "\n");
		fprintf (trio_gen_fp, "\n");
	}

	fclose (trio_hap_fp);
	fclose (trio_gen_fp);
	fclose (case_fp);
	fclose (anticase_fp);
	return 0;
}

static int
hapsample_simulate (hapsample_instance_t * hs)
{
	int nMaxSample ;
	/* load the user-supplied disease model */
	if (load_disease_models (hs))
		return 1;

	if (preprocess (hs))
		return 1;

	nMaxSample = hs->cases_cnt ;
	if(hs->cases_cnt < hs->anticases_cnt) nMaxSample = hs->anticases_cnt;
	
	simulate_set (hs, &hs->case_disease_model,
		      hs->case_haplotypes_filename,
		      hs->case_genotypes_filename,
			  hs->cases_cnt,
			  nMaxSample);
	simulate_set (hs, &hs->anticase_disease_model,
		      hs->anticase_haplotypes_filename,
		      hs->anticase_genotypes_filename,
			  hs->anticases_cnt,
			  nMaxSample);
	if (hs->user_prefs.simulation_type == TRIOS)
		write_trios (hs);
	return 0;
}

int
hapsample_simulate_case_controls (hapsample_instance_t * hs, int cases_cnt,
				  int anticases_cnt)
{
	hs->cases_cnt = cases_cnt * 2;
	hs->anticases_cnt = anticases_cnt * 2;
	hs->user_prefs.simulation_type = CASE_CONTROL;
	return hapsample_simulate (hs);
}

int
hapsample_simulate_trios (hapsample_instance_t * hs, int cnt)
{
	hs->cases_cnt = cnt * 2;
	hs->anticases_cnt = cnt * 2;
	hs->user_prefs.simulation_type = TRIOS;
	return hapsample_simulate (hs);
}

/*
This is called after initial load of database and user data
*/
int
preprocess (hapsample_instance_t * hs)
{
	int i, extra = 0;
	char *extra_names[22];
#ifdef _WIN32
    unsigned int pid = GetCurrentProcessId();
#else
	PID_T pid = getpid ();
#endif

	for (i = 0; i < 22; i++) {
		extra_names[i] = (char *) malloc (MAX_SNP_NAME_LEN);
		if (!extra_names[i])
			MEM ();
	}

	/* we simulate based on the user-supplied SNP list minus unknown
	   SNPs (relative to our database) plus user-supplied disease SNPs
	   (if not also named in the SNP list).  When we write the output,
	   however, we only write the user-supplied SNP list, so we need to
	   maintain the integrity of that list.
	 */
	/* determine total number of SNPs we are to simulate */
	for (i = 0; i < hs->case_disease_model.snp_name_cnt; i++) {
		if (bsearch
		    (&hs->case_disease_model.snp_names[i],
		     hs->user_prefs.snp_list, hs->user_prefs.snp_cnt,
		     sizeof (char *), cmpstringp) == NULL) {
			strcpy (extra_names[extra],
				hs->case_disease_model.snp_names[i]);
			extra++;
		}
	}
	hs->simulation_snp_cnt = hs->user_prefs.snp_cnt + extra;

	/* get records for all snps to simulate.  First,the user-defined ones */
	hs->simulation_records =
		(marker_record_t *) malloc (sizeof (marker_record_t) *
					    hs->simulation_snp_cnt);
	if (!hs->simulation_records)
		MEM ();

	get_marker_records (hs, hs->user_prefs.snp_list,
			    hs->user_prefs.snp_cnt, hs->simulation_records);

	/* now extras, if any */
	get_marker_records (hs, extra_names, extra,
			    &hs->simulation_records[hs->user_prefs.snp_cnt]);

	/* sort by chromosome */
	qsort (&hs->simulation_records[0], hs->simulation_snp_cnt,
	       sizeof (marker_record_t), cmpchromosomep);

	/* create chromosome map into that index */
	for (i = 0; i < 22; i++) {
		hs->simulation_snps_index[i] = -1;
		hs->simulation_snps_cnt[i] = 0;
	}
	for (i = 0; i < hs->simulation_snp_cnt; i++) {
		int cur_chr = hs->simulation_records[i].chromosome;
		hs->simulation_snps_cnt[cur_chr - 1]++;
		if (hs->simulation_snps_index[cur_chr - 1] != -1)
			continue;
		hs->simulation_snps_index[cur_chr - 1] = i;
	}

	/* now sort each chromosome by location */
	for (i = 0; i < 22; i++) {
		qsort (&hs->simulation_records[hs->simulation_snps_index[i]],
		       hs->simulation_snps_cnt[i], sizeof (marker_record_t),
		       cmplocationp);
	}

	for (i = 0; i < 22; i++)
		free (extra_names[i]);
	hs->max_snps = 0;
	for (i = 0; i < 22; i++) {
		if (hs->simulation_snps_cnt[i] > hs->max_snps) {
			hs->max_snps = hs->simulation_snps_cnt[i];
			hs->max_snps_chr = (i + 1);
		}
	}
	compute_probability_table (&hs->case_disease_model, hs->cases_cnt);
	compute_probability_table (&hs->anticase_disease_model,
				   hs->anticases_cnt);

	/* setup filenames */
	if (hs->user_prefs.simulation_type == TRIOS) {
		sprintf (hs->case_haplotypes_filename,
			 "%strans_haplotypes_%i.dat", hs->output_directory, pid);
		sprintf (hs->case_genotypes_filename,
			 "%strans_genotypes_%i.dat", hs->output_directory, pid);
		sprintf (hs->anticase_haplotypes_filename,
			 "%snontrans_haplotypes_%i.dat", hs->output_directory, pid);
		sprintf (hs->anticase_genotypes_filename,
			 "%snontrans_genotypes_%i.dat", hs->output_directory, pid);
	}
	else {
		sprintf (hs->case_haplotypes_filename, 
			 "%scase_haplotypes_%i.dat", hs->output_directory, pid);
		sprintf (hs->case_genotypes_filename, 
            "%scase_genotypes_%i.dat", hs->output_directory, pid);
		sprintf (hs->anticase_haplotypes_filename, 
			 "%santicase_haplotypes_%i.dat", hs->output_directory, pid);
		sprintf (hs->anticase_genotypes_filename, 
			 "%santicase_genotypes_%i.dat", hs->output_directory, pid);
	}
	sprintf (hs->trio_haplotypes_filename, "%strio_haplotypes_%i.dat", hs->output_directory, pid);
	sprintf (hs->trio_genotypes_filename, "%strio_genotypes_%i.dat", hs->output_directory, pid);

	return 0;
}

int
rutgers_markers_load (hapsample_instance_t * hs)
{
	hs->rutgers_markers = load_rutgers_markers (hs->rutgers_markers_dir);
	if (!hs->rutgers_markers)
		return 1;

	return 0;
}

int
hapsample_initialize (hapsample_instance_t * hs, char *db_prefix,
		      char *user_snp_list_file, char *user_disease_model_file, char* output_dirname,
		      double recombination_factor)
{
	memset (hs, 0, sizeof (hapsample_instance_t));

	/* setup filenames */
	if (user_snp_list_file)
		strcpy (hs->user_prefs.snp_list_file, user_snp_list_file);
	if (user_disease_model_file)
		strcpy (hs->user_prefs.disease_model_file,
			user_disease_model_file);

    if (output_dirname)
    {
        strcpy(hs->output_directory, output_dirname);
        if (hs->output_directory[strlen(output_dirname)-1] != '/')
        {
            hs->output_directory[strlen(output_dirname)] = '/';   
            hs->output_directory[strlen(output_dirname)+1] = '\0';   
        }
    }

#ifdef  _WIN32
    strcpy (hs->database_name, db_prefix);
    strcpy (hs->database_dir, db_prefix);
#else
    strcpy (hs->database_name, basename (db_prefix));
 	strcpy (hs->database_dir, dirname (db_prefix));
#endif
	strcpy (hs->rutgers_markers_dir, hs->database_dir);
	hs->recombination_factor = recombination_factor;

	/* open files used during session */
#ifdef  _WIN32
    sprintf (hs->summary_file, "%s/%s.hap", hs->database_dir, db_prefix);
    sprintf (hs->records_file, "%s/%s.rec", hs->database_dir, db_prefix);
    sprintf (hs->genotypes_file, "%s/%s.gen", hs->database_dir, db_prefix);
    sprintf (hs->id_index_file, "%s/%s.idx", hs->database_dir, db_prefix);
#else
    sprintf (hs->summary_file, "%s.hap", db_prefix);
    sprintf (hs->records_file, "%s.rec", db_prefix);
    sprintf (hs->genotypes_file, "%s.gen", db_prefix);
    sprintf (hs->id_index_file, "%s.idx", db_prefix);
#endif
    hs->records_fp = fopen (hs->records_file, "rb");
    hs->genotypes_fp = fopen (hs->genotypes_file, "rb");

	/* TODO: validate files here */
	if (rutgers_markers_load (hs))
		return 1;

	/* load the summary file */
	if (summary_load (hs))
		return 1;

	/* load the SNP id index file */
	if (load_id_index (hs))
		return 1;

	/* load the user-supplied list of SNPs */
	if (user_snp_list_file)
		if (load_user_snps (hs))
			return 1;

	return 0;

}

void
hapsample_cleanup (hapsample_instance_t * hs)
{
	free_rutgers_markers (hs->rutgers_markers);
	if (hs->id_index)
		free (hs->id_index);
	if (hs->simulation_records)
		free (hs->simulation_records);
	if (hs->user_prefs.snp_list) {
		free_strings (hs->user_prefs.snp_list,
			      hs->user_prefs.snp_cnt);
	}
	if (hs->records_fp)
		fclose (hs->records_fp);
	if (hs->genotypes_fp)
		fclose (hs->genotypes_fp);
	disease_free (&hs->case_disease_model);
	disease_free (&hs->anticase_disease_model);
	if (g_samples != NULL) {
		int i;
		for (i = 0; i < hs->max_snps; i++)
			if (g_samples[i])
				free (g_samples[i]);
		free (g_samples);
	}
	if (g_new_samples != NULL) {
		int i;
		for (i = 0; i < hs->max_snps; i++)
			if (g_new_samples[i])
				free (g_new_samples[i]);
		free (g_new_samples);
	}
}
